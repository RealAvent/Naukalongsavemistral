# Facebook AutoRunner – Zoptymalizowany
# Zawiera scrollowanie, dodawanie znajomych, lajkowanie fanpage, config, GUI, debug, obsługę wyjątków

import asyncio
import random
import time
import json
import yaml
import requests
import tkinter as tk
from tkinter import scrolledtext
from pyppeteer import connect
import sys
import os

def log(msg: str):
    print(f"[LOG] {msg}")

def write_debug(pid: int, line: str):
    with open(f"debug_{pid}.log", "a", encoding="utf-8") as f:
        f.write(line + "\n")

def load_config():
    with open("config.yaml", "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def load_profiles():
    with open("profile.json", "r", encoding="utf-8") as f:
        data = json.load(f)
    return data.get("profile_ids", [])

def start_profile(pid):
    url = f"http://localhost:3001/v1.0/browser_profiles/{pid}/start?automation=1"
    for attempt in range(5):
        try:
            r = requests.get(url, timeout=10)
            r.raise_for_status()
            log(f"Profil {pid} uruchomiony.")
            time.sleep(5)
            return r.json()
        except Exception as e:
            log(f"[{pid}] Retry {attempt+1}/5: {e}")
            time.sleep(2)
    raise RuntimeError(f"[{pid}] Nie udało się uruchomić profilu.")

def stop_profile(pid):
    url = f"http://localhost:3001/v1.0/browser_profiles/{pid}/stop"
    try:
        requests.get(url, timeout=5)
        log(f"Profil {pid} zamknięty.")
    except Exception as e:
        log(f"⚠️ Nie udało się zamknąć profilu {pid}: {e}")

class TextRedirector:
    def __init__(self, widget):
        self.widget = widget
    def write(self, s):
        self.widget.configure(state='normal')
        self.widget.insert(tk.END, s)
        self.widget.see(tk.END)
        self.widget.configure(state='disabled')
    def flush(self): pass

def run_gui():
    root = tk.Tk()
    root.title("Facebook AutoRunner")
    root.geometry("800x600")
    root.configure(bg="#23272f")

    log_box = scrolledtext.ScrolledText(root, bg="#181a20", fg="#00ff99", font=("Consolas", 10), state='disabled')
    log_box.pack(fill="both", expand=True, padx=10, pady=10)

    def run():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(main())
        loop.close()

    def start():
        import threading
        threading.Thread(target=run, daemon=True).start()

    btn = tk.Button(root, text="START", font=("Segoe UI", 13, "bold"),
        bg="#00bfff", fg="#23272f", command=start)
    btn.pack(pady=10)

    sys.stdout = TextRedirector(log_box)
    sys.stderr = TextRedirector(log_box)
    root.mainloop()

async def simulate_facebook_actions(page, pid):
    try:
        info = await page.evaluate('''() => ({
            width: window.innerWidth,
            height: window.innerHeight,
            dpr: window.devicePixelRatio,
            webdriver: navigator.webdriver,
            visibility: document.visibilityState
        })''')
        write_debug(pid, f"[DEBUG] DPR={info['dpr']}, size={info['width']}x{info['height']}, webdriver={info['webdriver']}")

        session_time = random.randint(90, 240)
        end_time = time.time() + session_time
        i = 0

        while time.time() < end_time:
            await page._client.send("Input.dispatchMouseEvent", {
                "type": "mouseWheel", "x": random.randint(300, 700), "y": random.randint(300, 700),
                "deltaX": 0, "deltaY": random.randint(200, 900)
            })
            i += 1
            log(f"[{pid}] Scroll {i}")
            write_debug(pid, f"[SCROLL {i}] OK")
            await asyncio.sleep(random.uniform(3.0, 5.0))

    except Exception as e:
        err = f"[simulate_facebook_actions] Błąd: {str(e)}"
        log(err)
        write_debug(pid, err)

async def run_profile(pid):
    try:
        prof = start_profile(pid)
        port = prof["automation"]["port"]
        ws = prof["automation"]["wsEndpoint"]
        ws_url = f"ws://127.0.0.1:{port}{ws}"
        log(f"[{pid}] WebSocket: {ws_url}")

        browser = await connect(browserWSEndpoint=ws_url)
        page = await browser.newPage()
        await page.setViewport({"width": 1366, "height": 768})
        await page.goto("https://www.facebook.com")
        await asyncio.sleep(3)
        log(f"[{pid}] Sesja aktywna, rozpoczynam symulację.")
        await simulate_facebook_actions(page, pid)
        await browser.disconnect()
    except Exception as e:
        log(f"[{pid}] WebSocket ERROR: {e}")
        write_debug(pid, f"[{pid}] WebSocket ERROR: {e}")
    finally:
        stop_profile(pid)

async def main():
    config = load_config()
    pids = load_profiles()
    for pid in pids:
        try:
            await run_profile(pid)
        except Exception as e:
            log(f"[{pid}] ERROR: {str(e)}")
            write_debug(pid, f"[FATAL] {str(e)}")

if __name__ == "__main__":
    run_gui()

# Facebook AutoRunner – Zoptymalizowany
# Zawiera scrollowanie, dodawanie znajomych, lajkowanie fanpage, config, GUI, debug, obsługę wyjątków

import asyncio
import random
import time
import json
import yaml
import requests
import tkinter as tk
from tkinter import scrolledtext
from pyppeteer import connect
import sys
import os

def log(msg: str):
    print(f"[LOG] {msg}")

def write_debug(pid: int, line: str):
    with open(f"debug_{pid}.log", "a", encoding="utf-8") as f:
        f.write(line + "\n")

def load_config():
    with open("config.yaml", "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def load_profiles():
    with open("profile.json", "r", encoding="utf-8") as f:
        data = json.load(f)
    return data.get("profile_ids", [])

def start_profile(pid):
    url = f"http://localhost:3001/v1.0/browser_profiles/{pid}/start?automation=1"
    for attempt in range(5):
        try:
            r = requests.get(url, timeout=10)
            r.raise_for_status()
            log(f"Profil {pid} uruchomiony.")
            time.sleep(5)
            return r.json()
        except Exception as e:
            log(f"[{pid}] Retry {attempt+1}/5: {e}")
            time.sleep(2)
    raise RuntimeError(f"[{pid}] Nie udało się uruchomić profilu.")

def stop_profile(pid):
    url = f"http://localhost:3001/v1.0/browser_profiles/{pid}/stop"
    try:
        requests.get(url, timeout=5)
        log(f"Profil {pid} zamknięty.")
    except Exception as e:
        log(f"⚠️ Nie udało się zamknąć profilu {pid}: {e}")

class TextRedirector:
    def __init__(self, widget):
        self.widget = widget
    def write(self, s):
        self.widget.configure(state='normal')
        self.widget.insert(tk.END, s)
        self.widget.see(tk.END)
        self.widget.configure(state='disabled')
    def flush(self): pass

def run_gui():
    root = tk.Tk()
    root.title("Facebook AutoRunner")
    root.geometry("800x600")
    root.configure(bg="#23272f")

    log_box = scrolledtext.ScrolledText(root, bg="#181a20", fg="#00ff99", font=("Consolas", 10), state='disabled')
    log_box.pack(fill="both", expand=True, padx=10, pady=10)

    def run():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(main())
        loop.close()

    def start():
        import threading
        threading.Thread(target=run, daemon=True).start()

    btn = tk.Button(root, text="START", font=("Segoe UI", 13, "bold"),
        bg="#00bfff", fg="#23272f", command=start)
    btn.pack(pady=10)

    sys.stdout = TextRedirector(log_box)
    sys.stderr = TextRedirector(log_box)
    root.mainloop()

async def simulate_facebook_actions(page, pid):
    try:
        info = await page.evaluate('''() => ({
            width: window.innerWidth,
            height: window.innerHeight,
            dpr: window.devicePixelRatio,
            webdriver: navigator.webdriver,
            visibility: document.visibilityState
        })''')
        write_debug(pid, f"[DEBUG] DPR={info['dpr']}, size={info['width']}x{info['height']}, webdriver={info['webdriver']}")

        session_time = random.randint(90, 240)
        end_time = time.time() + session_time
        i = 0

        while time.time() < end_time:
            await page._client.send("Input.dispatchMouseEvent", {
                "type": "mouseWheel", "x": random.randint(300, 700), "y": random.randint(300, 700),
                "deltaX": 0, "deltaY": random.randint(200, 900)
            })
            i += 1
            log(f"[{pid}] Scroll {i}")
            write_debug(pid, f"[SCROLL {i}] OK")
            await asyncio.sleep(random.uniform(3.0, 5.0))

    except Exception as e:
        err = f"[simulate_facebook_actions] Błąd: {str(e)}"
        log(err)
        write_debug(pid, err)

async def run_profile(pid):
    try:
        prof = start_profile(pid)
        port = prof["automation"]["port"]
        ws = prof["automation"]["wsEndpoint"]
        ws_url = f"ws://127.0.0.1:{port}{ws}"
        log(f"[{pid}] WebSocket: {ws_url}")

        browser = await connect(browserWSEndpoint=ws_url)
        page = await browser.newPage()
        await page.setViewport({"width": 1366, "height": 768})
        await page.goto("https://www.facebook.com")
        await asyncio.sleep(3)
        log(f"[{pid}] Sesja aktywna, rozpoczynam symulację.")
        await simulate_facebook_actions(page, pid)
        await browser.disconnect()
    except Exception as e:
        log(f"[{pid}] WebSocket ERROR: {e}")
        write_debug(pid, f"[{pid}] WebSocket ERROR: {e}")
    finally:
        stop_profile(pid)

async def main():
    config = load_config()
    pids = load_profiles()
    for pid in pids:
        try:
            await run_profile(pid)
        except Exception as e:
            log(f"[{pid}] ERROR: {str(e)}")
            write_debug(pid, f"[FATAL] {str(e)}")

if __name__ == "__main__":
    run_gui()

# Facebook AutoRunner – Zoptymalizowany
# Zawiera scrollowanie, dodawanie znajomych, lajkowanie fanpage, config, GUI, debug, obsługę wyjątków

import asyncio
import random
import time
import json
import yaml
import requests
import tkinter as tk
from tkinter import scrolledtext
from pyppeteer import connect
import sys
import os

def log(msg: str):
    print(f"[LOG] {msg}")

def write_debug(pid: int, line: str):
    with open(f"debug_{pid}.log", "a", encoding="utf-8") as f:
        f.write(line + "\n")

def load_config():
    with open("config.yaml", "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def load_profiles():
    with open("profile.json", "r", encoding="utf-8") as f:
        data = json.load(f)
    return data.get("profile_ids", [])

def start_profile(pid):
    url = f"http://localhost:3001/v1.0/browser_profiles/{pid}/start?automation=1"
    for attempt in range(5):
        try:
            r = requests.get(url, timeout=10)
            r.raise_for_status()
            log(f"Profil {pid} uruchomiony.")
            time.sleep(5)
            return r.json()
        except Exception as e:
            log(f"[{pid}] Retry {attempt+1}/5: {e}")
            time.sleep(2)
    raise RuntimeError(f"[{pid}] Nie udało się uruchomić profilu.")

def stop_profile(pid):
    url = f"http://localhost:3001/v1.0/browser_profiles/{pid}/stop"
    try:
        requests.get(url, timeout=5)
        log(f"Profil {pid} zamknięty.")
    except Exception as e:
        log(f"⚠️ Nie udało się zamknąć profilu {pid}: {e}")

class TextRedirector:
    def __init__(self, widget):
        self.widget = widget
    def write(self, s):
        self.widget.configure(state='normal')
        self.widget.insert(tk.END, s)
        self.widget.see(tk.END)
        self.widget.configure(state='disabled')
    def flush(self): pass

def run_gui():
    root = tk.Tk()
    root.title("Facebook AutoRunner")
    root.geometry("800x600")
    root.configure(bg="#23272f")

    log_box = scrolledtext.ScrolledText(root, bg="#181a20", fg="#00ff99", font=("Consolas", 10), state='disabled')
    log_box.pack(fill="both", expand=True, padx=10, pady=10)

    def run():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(main())
        loop.close()

    def start():
        import threading
        threading.Thread(target=run, daemon=True).start()

    btn = tk.Button(root, text="START", font=("Segoe UI", 13, "bold"),
        bg="#00bfff", fg="#23272f", command=start)
    btn.pack(pady=10)

    sys.stdout = TextRedirector(log_box)
    sys.stderr = TextRedirector(log_box)
    root.mainloop()

async def simulate_facebook_actions(page, pid):
    try:
        info = await page.evaluate('''() => ({
            width: window.innerWidth,
            height: window.innerHeight,
            dpr: window.devicePixelRatio,
            webdriver: navigator.webdriver,
            visibility: document.visibilityState
        })''')
        write_debug(pid, f"[DEBUG] DPR={info['dpr']}, size={info['width']}x{info['height']}, webdriver={info['webdriver']}")

        session_time = random.randint(90, 240)
        end_time = time.time() + session_time
        i = 0

        while time.time() < end_time:
            await page._client.send("Input.dispatchMouseEvent", {
                "type": "mouseWheel", "x": random.randint(300, 700), "y": random.randint(300, 700),
                "deltaX": 0, "deltaY": random.randint(200, 900)
            })
            i += 1
            log(f"[{pid}] Scroll {i}")
            write_debug(pid, f"[SCROLL {i}] OK")
            await asyncio.sleep(random.uniform(3.0, 5.0))

    except Exception as e:
        err = f"[simulate_facebook_actions] Błąd: {str(e)}"
        log(err)
        write_debug(pid, err)

async def run_profile(pid):
    try:
        prof = start_profile(pid)
        port = prof["automation"]["port"]
        ws = prof["automation"]["wsEndpoint"]
        ws_url = f"ws://127.0.0.1:{port}{ws}"
        log(f"[{pid}] WebSocket: {ws_url}")

        browser = await connect(browserWSEndpoint=ws_url)
        page = await browser.newPage()
        await page.setViewport({"width": 1366, "height": 768})
        await page.goto("https://www.facebook.com")
        await asyncio.sleep(3)
        log(f"[{pid}] Sesja aktywna, rozpoczynam symulację.")
        await simulate_facebook_actions(page, pid)
        await browser.disconnect()
    except Exception as e:
        log(f"[{pid}] WebSocket ERROR: {e}")
        write_debug(pid, f"[{pid}] WebSocket ERROR: {e}")
    finally:
        stop_profile(pid)

async def main():
    config = load_config()
    pids = load_profiles()
    for pid in pids:
        try:
            await run_profile(pid)
        except Exception as e:
            log(f"[{pid}] ERROR: {str(e)}")
            write_debug(pid, f"[FATAL] {str(e)}")

if __name__ == "__main__":
    run_gui()